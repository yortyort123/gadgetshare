<?php
session_start();
include("db.php");

$user_id = $_SESSION['user_id'];
$firstName = htmlspecialchars(trim($_POST['firstName']));
$lastName = htmlspecialchars(trim($_POST['lastName']));
$email = htmlspecialchars(trim($_POST['email']));
$password = htmlspecialchars(trim($_POST['password']));
$profilePic = $_FILES['profilePic'];

if (!empty($profilePic['name'])) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($profilePic["name"]);
    move_uploaded_file($profilePic["tmp_name"], $target_file);
    $photo = $target_file;
    $stmt = $con->prepare("UPDATE `form` SET photo = ? WHERE id = ?");
    $stmt->bind_param("si", $photo, $user_id);
    $stmt->execute();
    $_SESSION['photo'] = $photo;
    $stmt->close();
}

if (!empty($password)) {
    $stmt = $con->prepare("UPDATE `form` SET Password = ? WHERE id = ?");
    $stmt->bind_param("si", $password, $user_id);
    $stmt->execute();
    $stmt->close();
}

$stmt = $con->prepare("UPDATE `form` SET Fname = ?, Lname = ?, Email = ? WHERE id = ?");
$stmt->bind_param("sssi", $firstName, $lastName, $email, $user_id);
$stmt->execute();
$stmt->close();

$_SESSION['Fname'] = $firstName;
$_SESSION['Lname'] = $lastName;
$_SESSION['Email'] = $email;

header("Location: profile.php");
exit();
?>
