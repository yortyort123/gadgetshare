<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$firstName = $_SESSION['Fname'];
$lastName = $_SESSION['Lname'];
$email = $_SESSION['Email'];
$photo = $_SESSION['photo'] ? $_SESSION['photo'] : 'image/profile-placeholder.png';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gadget Share - Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="css/profile.css">
</head>
<body>
<header>
    <nav class="navbar">
        <ul>
            <li><a href="home.php"><i class="fas fa-home"></i> Services</a></li>
            <li><a href="#"><i class="fas fa-comment"></i> Message</a></li>
            <li><a href="#"><i class="fas fa-receipt"></i> Notification</a></li>
            <li><a href="#"><i class="fas fa-cash-register"></i> Payments</a></li>
            <li><a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
            <li><a href="profile.php" id="profile-link"><i class="fas fa-user"></i> Profile</a></li>
        </ul>
    </nav>
</header>

<section class="profile-details">
    <div class="profile-img">
        <img src="<?php echo $photo; ?>" alt="Profile Picture" id="profile-picture">
    </div>
    <div class="profile-info">
        <h2 id="username"><?php echo $firstName . ' ' . $lastName; ?></h2>
        <p id="email"><?php echo $email; ?></p>
        <button class="btn" onclick="openModal()">Update Profile</button>
    </div>
</section>

<div id="updateModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <form id="profileForm" action="update_profile.php" method="post" enctype="multipart/form-data">
            <label for="profilePic">Profile Picture:</label>
            <input type="file" id="profilePic" name="profilePic" accept="image/*"><br><br>
            <label for="firstName">First Name:</label>
            <input type="text" id="firstName" name="firstName" value="<?php echo $firstName; ?>"><br><br>
            <label for="lastName">Last Name:</label>
            <input type="text" id="lastName" name="lastName" value="<?php echo $lastName; ?>"><br><br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $email; ?>"><br><br>
            <label for="password">New Password:</label>
            <input type="password" id="password" name="password"><br><br>
            <button type="submit" class="btn">Save Changes</button>
        </form>
    </div>
</div>

<script src="profile.js"></script>
</body>
</html>
