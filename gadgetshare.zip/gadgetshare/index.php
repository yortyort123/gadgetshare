<?php
session_start();
include("db.php");

if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['signup'])) {
    $fname = htmlspecialchars(trim($_POST['Fname']));
    $lname = htmlspecialchars(trim($_POST['Lname']));
    $email = htmlspecialchars(trim($_POST['Email']));
    $pass = htmlspecialchars(trim($_POST['Password']));

    if (!empty($email) && !empty($pass) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $stmt = $con->prepare("INSERT INTO `form` (Fname, Lname, Email, Password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fname, $lname, $email, $pass);
        $stmt->execute();
        $stmt->close();
        echo "<script type='text/javascript'>alert('Successfully Registered!');</script>";
    } else {
        echo "<script type='text/javascript'>alert('Please enter valid information');</script>";
    }
}

if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['login'])) {
    $email = htmlspecialchars(trim($_POST['Email']));
    $pass = htmlspecialchars(trim($_POST['Password']));

    if (!empty($email) && !empty($pass) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $stmt = $con->prepare("SELECT * FROM `form` WHERE Email = ? AND Password = ? LIMIT 1");
        $stmt->bind_param("ss", $email, $pass);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $user_data = $result->fetch_assoc();
            $_SESSION['user_id'] = $user_data['id'];
            $_SESSION['Fname'] = $user_data['Fname'];
            $_SESSION['Lname'] = $user_data['Lname'];
            $_SESSION['Email'] = $user_data['Email'];
            $_SESSION['photo'] = $user_data['photo'];
            echo "<script type='text/javascript'>alert('Login Successful!');</script>";
            header("Location: home.php");
            exit;
        } else {
            echo "<script type='text/javascript'>alert('Invalid login credentials');</script>";
        }
        $stmt->close();
    } else {
        echo "<script type='text/javascript'>alert('Please enter valid information');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>Gadget Share</title>
</head>
<body>
    <header>
        <a href="#" class="logo"><img src="image/drivers.png" alt=""></a>
        <div class="bx bx-menu" id="menu-icon"></div>
        <ul class="navbar">
            <li><a href="#home">Home</a></li>
            <li><a href="#rent">How It Works?</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#reviews">Review</a></li>
            <li><a href="#about">About</a></li>
        </ul>
        <div class="header-btn">
            <button type="button" class="header-btn-login" data-bs-toggle="modal" data-bs-target="#login-modal">Login</button>
            <button type="button" class="header-btn-signup" data-bs-toggle="modal" data-bs-target="#signup-modal">Sign Up</button>
        </div>
    </header>
    
    <section class="home" id="home">
        <div class="text">
            <h1><span>Looking</span> to <br>rent a gadget</h1>
            <p>Gadget Share is a platform where you can rent gadgets.</p>
            <div class="app-stores">
                <img src="image/playstore1.png" alt="">
                <img src="image/appstore1.png" alt="" id="appstore">
            </div>
        </div>
    </section>
  
    <!-- Login Modal -->
    <div class="modal fade" id="login-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Login</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="login-email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="login-email" name="Email" required>
                        </div>
                        <div class="mb-3">
                            <label for="login-password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="login-password" name="Password" required>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" name="login" class="btn btn-primary">Login</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Sign-Up Modal -->
    <div class="modal fade" id="signup-modal" tabindex="-1" aria-labelledby="signupModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="signupModalLabel">Sign Up</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="signup-name" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="signup-name" name="Fname" required>
                        </div>
                        <div class="mb-3">
                            <label for="signup-lname" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="signup-lname" name="Lname" required>
                        </div>
                        <div class="mb-3">
                            <label for="signup-email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="signup-email" name="Email" required>
                        </div>
                        <div class="mb-3">
                            <label for="signup-password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="signup-password" name="Password" required>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" name="signup" class="btn btn-primary">Sign Up</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
