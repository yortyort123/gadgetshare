<?php
include("db.php");
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gadget Share</title>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <nav>
        <ul>
            <li><a href="#">
                <i class="fas fa-home"></i>
                <span class="nav-item">Services</span>
            </a></li>
            <li><a href="#">
                <i class="fas fa-comment"></i>
                <span class="nav-item">Message</span>
            </a></li>
            <li><a href="#">
                <i class="fas fa-receipt"></i>
                <span class="nav-item">Notification</span>
            </a></li>
            <li><a href="#">
                <i class="fas fa-cash-register"></i>
                <span class="nav-item">Payments</span>
            </a></li>
            <li><a href="logout.php" class="logout">
                <i class="fas fa-sign-out-alt"></i>
                <span class="nav-item">Log Out</span>
            </a></li>
            <li><a href="profile.php">
                <i class="fas fa-user"></i>
                <span class="nav-item">Profile</span>
            </a></li>
        </ul>
    </nav>

    <header>
        <a href="#" class="logo"><img src="image/drivers.png" alt=""></a>
        
        <ul class="navbar">
            <li>
                <a href="#home">Laptop</a>
                <div class="dropdown-content">
                    <div class="dropdown-item">
                        <a href="#">ASUS TUF F15</a>
                        <img src="image/laptop1.jpg" alt="Laptop 1 Image" class="dropdown-img">
                    </div>
                    <div class="dropdown-item">
                        <a href="#">Macbook Pro M2</a>
                        <img src="image/laptop2.jpg" alt="Laptop 2 Image" class="dropdown-img">
                    </div>
                    <div class="dropdown-item">
                        <a href="#">Lenovo Legion Pro</a>
                        <img src="image/laptop3.jpg" alt="Laptop 3 Image" class="dropdown-img">
                    </div>
                </div>
            </li>
            <li>
                <a href="#rent">Projector</a>
                <div class="dropdown-content">
                    <div class="dropdown-item">
                        <a href="#">Epson EB-2165W</a>
                        <img src="image/projector1.png" alt="Projector 1 Image" class="dropdown-img">
                    </div>
                    <div class="dropdown-item">
                        <a href="#">Epson EH-LS12000B</a>
                        <img src="image/projector2.jpg" alt="Projector 2 Image" class="dropdown-img">
                    </div>
                    <div class="dropdown-item">
                        <a href="#">EPSON EB-E01</a>
                        <img src="image/projector3.jpg" alt="Projector 3 Image" class="dropdown-img">
                    </div>
                </div>
            </li>
            <li>
                <a href="#services">Camera</a>
                <div class="dropdown-content">
                    <div class="dropdown-item">
                        <a href="#">InstaX</a>
                        <img src="image/camera1.png" alt="Camera 1 Image" class="dropdown-img">
                    </div>
                    <div class="dropdown-item">
                        <a href="#">Canon EOS R7</a>
                        <img src="image/camera2.jpg" alt="Camera 2 Image" class="dropdown-img">
                    </div>
                    <div class="dropdown-item">
                        <a href="#">DSLR</a>
                        <img src="image/camera3.jpg" alt="Camera 3 Image" class="dropdown-img">
                    </div>
                </div>
            </li>
        </ul>
    
        <div class="header-btn">
            <a href="#" class="login-btn" id="login-btn">Start Listing</a>
        </div>
    </header>
<script src="listing.js"></script>
</body>
</html>
